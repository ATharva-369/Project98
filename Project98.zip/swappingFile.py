# create a function to use the files
def swap_the_files():
    #using text input to get the file names
    file_name1 = input("enter the name of the 1st file: ")
    file_name2 = input("enter the name of the 2nd file: ")
    # opening the files in read-only mode
    file1 = open(file_name1)
    file2 = open(file_name2)
    #storing the data of the files into variables
    file1_data = file1.readlines()
    file2_data = file2.readlines()
    #closing the files in read-only mode
    file1.close()
    file2.close()
    # opening the files in write-only mode
    file1 = open(file_name1, 'w')
    file2 = open(file_name2, 'w')
    # swapping the data using the variables and writelines() function
    file1.writelines(file2_data)
    file2.writelines(file1_data)
    # closing the files
    file1.close()
    file2.close()

#calling out the function we created
swap_the_files()
